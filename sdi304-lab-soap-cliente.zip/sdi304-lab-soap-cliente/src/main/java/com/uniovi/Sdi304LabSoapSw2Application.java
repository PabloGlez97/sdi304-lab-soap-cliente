package com.uniovi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sdi304LabSoapSw2Application {

	public static void main(String[] args) {
		SpringApplication.run(Sdi304LabSoapSw2Application.class, args);
	}

}
